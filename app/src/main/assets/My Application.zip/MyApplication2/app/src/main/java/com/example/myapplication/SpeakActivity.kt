package com.example.myapplication

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.myapplication.database.AppDatabase
import com.example.myapplication.database.Schedule
import com.example.myapplication.database.ScheduleDao
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SpeakActivity : AppCompatActivity() {

    private lateinit var speechRecognizer: SpeechRecognizer
    private var isListening = false
    private lateinit var voiceButton: Button
    private lateinit var recognizedText: TextView
    private var timeoutHandler: Handler? = null
    private lateinit var database: AppDatabase
    private lateinit var scheduleDao: ScheduleDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_speak)

        voiceButton = findViewById(R.id.voiceButton)
        recognizedText = findViewById(R.id.recognizedText)

        // Initialize database
        database = AppDatabase.getDatabase(this)
        scheduleDao = database.scheduleDao()

        // Check permissions
        checkPermissions()

        // Initialize SpeechRecognizer
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer.setRecognitionListener(object : RecognitionListenerAdapter() {
            override fun onResults(results: Bundle?) {
                timeoutHandler?.removeCallbacksAndMessages(null) // Stop the timeout handler
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    val spokenText = matches[0]
                    Log.d("VoiceRecognition", "Recognized Text: $spokenText")
                    runOnUiThread {
                        recognizedText.text = spokenText
                    }
                    handleVoiceCommand(spokenText)
                } else {
                    Log.d("VoiceRecognition", "No text recognized")
                    runOnUiThread {
                        recognizedText.text = "Tidak ada teks yang dikenali."
                    }
                }
            }

            override fun onError(error: Int) {
                timeoutHandler?.removeCallbacksAndMessages(null) // Stop timeout on error
                if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                    isListening = false
                    runOnUiThread {
                        recognizedText.text = getString(R.string.recognizer_busy)
                        Toast.makeText(
                            this@SpeakActivity,
                            getString(R.string.recognizer_busy),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    runOnUiThread {
                        recognizedText.text = getString(R.string.error_message, error)
                    }
                }
            }

            override fun onEndOfSpeech() {
                stopListening()
            }
        })

        // Voice Button Listener
        voiceButton.setOnClickListener {
            if (isListening) {
                stopListening()
            } else {
                startListening()
            }
        }
    }

    private fun checkPermissions() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                1
            )
        }
    }

    private fun startListening() {
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            if (!isListening) {
                isListening = true
                voiceButton.text = getString(R.string.recording_icon)

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
                }
                speechRecognizer.startListening(intent)

                // Start 5-second timeout for no input
                timeoutHandler = Handler(mainLooper)
                timeoutHandler?.postDelayed({
                    if (isListening) {
                        stopListening()
                        runOnUiThread {
                            recognizedText.text = getString(R.string.timeout_message)
                        }
                        Toast.makeText(this, getString(R.string.timeout_message), Toast.LENGTH_SHORT).show()
                    }
                }, 5000) // 5000 ms = 5 seconds
            }
        } else {
            Toast.makeText(this, "Speech recognition is not available on this device.", Toast.LENGTH_SHORT).show()
        }
    }


    private fun stopListening() {
        isListening = false
        voiceButton.text = getString(R.string.mic_icon)
        speechRecognizer.stopListening()

        // Stop timeout if any
        timeoutHandler?.removeCallbacksAndMessages(null)
    }
    private fun parseCommand(input: String): Map<String, String> {
        val result = mutableMapOf<String, String>()

        Log.d("parseCommand", "Input: $input")

        // Extract time using regex
        val timeRegex = Regex("jam\\s*(\\d{1,2})\\s*(pagi|siang|sore|malam)?", RegexOption.IGNORE_CASE)
        val timeMatch = timeRegex.find(input)
        if (timeMatch != null) {
            val hour = timeMatch.groupValues[1].toInt()
            val period = timeMatch.groupValues[2]?.lowercase(Locale.getDefault()) ?: ""

            val adjustedHour = when (period) {
                "pagi" -> if (hour == 12) 0 else hour
                "siang" -> if (hour == 12) 12 else hour
                "sore", "malam" -> if (hour < 12) hour + 12 else hour
                else -> hour
            }

            result["time"] = String.format(Locale.getDefault(), "%02d:00", adjustedHour)
        } else {
            result["time"] = "00:00" // Default time if not found
        }

        if (result["label"].isNullOrEmpty()) {
            result["label"] = "Default Label" // Provide a default label if empty
        }

        // Extract label and description
        if (input.contains("ingatkan saya", ignoreCase = true)) {
            val withoutCommand = input.replace("ingatkan saya", "", ignoreCase = true).trim()
            val parts = withoutCommand.split("jam").map { it.trim() }
            val mainPart = parts.getOrNull(0) ?: ""

            // Split mainPart into label and description
            val labelRegex = Regex("(minum obat)(.*)", RegexOption.IGNORE_CASE)
            val match = labelRegex.find(mainPart)

            if (match != null) {
                result["label"] = match.groupValues[1].trim() // e.g., "minum obat"
                result["description"] = match.groupValues[2].trim() // e.g., "paracetamol 100mg"
            } else {
                result["label"] = mainPart // Fallback to using the main part as label
                result["description"] = "" // Description is empty if no match
            }
        } else {
            result["error"] = "Tidak dapat mengenali tindakan dalam perintah."
        }

        Log.d("parseCommand", "Parsed result: $result")
        return result
    }



    private fun handleVoiceCommand(command: String) {
        val parsedData = parseCommand(command)
        Log.d("VoiceCommand", "Input: $command")
        Log.d("VoiceCommand", "Parsed Data: $parsedData")

        if (parsedData.containsKey("error")) {
            runOnUiThread {
                Toast.makeText(this, parsedData["error"], Toast.LENGTH_SHORT).show()
            }
            return
        }

        val label = parsedData["label"]
        val time = parsedData["time"]
        val description = parsedData["description"] ?: ""

        if (label != null && time != null) {
            // Save to database
            val currentTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
            val newSchedule = Schedule(
                label = label,
                description = description,
                inputTime = time,
                creationTime = currentTime
            )
            saveScheduleToDatabase(newSchedule)

            runOnUiThread {
                Toast.makeText(
                    this,
                    getString(R.string.schedule_added, label, description, time),
                    Toast.LENGTH_SHORT
                ).show()
            }
        } else {
            runOnUiThread {
                Toast.makeText(this, getString(R.string.command_not_understood), Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun saveScheduleToDatabase(schedule: Schedule) {
        CoroutineScope(Dispatchers.IO).launch {
            scheduleDao.insert(schedule)
            Log.d("Database", "Jadwal berhasil disimpan: $schedule") // Add this log
        }
    }


    override fun onDestroy() {
        super.onDestroy()
        speechRecognizer.destroy()
    }
}
